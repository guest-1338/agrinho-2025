// Variáveis do jogo
let balloons = []; // Array para armazenar os balões
let score = 0;
let lastBalloonTime = 0;
const balloonInterval = 1000; // Intervalo de 1 segundo para novos balões
let popSound; // Variável para o som de estouro

// Classe para partículas de explosão (confetes)
class Particle {
  constructor(x, y, color) {
    this.x = x;
    this.y = y;
    this.color = color;
    this.vx = random(-2, 2);
    this.vy = random(-5, -1);
    this.alpha = 255;
    this.gravity = 0.1;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += this.gravity; // Aplica gravidade
    this.alpha -= 5; // Faz as partículas desaparecerem
  }

  display() {
    noStroke();
    fill(red(this.color), green(this.color), blue(this.color), this.alpha);
    ellipse(this.x, this.y, 5);
  }

  isFinished() {
    return this.alpha < 0;
  }
}

// Classe Balão Junino
class Balloon {
  constructor(x, y, r, speed) {
    this.x = x;
    this.y = y;
    this.r = r; // Raio base do balão
    this.speed = speed;
    this.color = color(random(100, 255), random(100, 255), random(100, 255)); // Cores vibrantes
    this.particles = []; // Partículas para o efeito de estouro
    this.popped = false;
  }

  // Desenha o balão com um formato mais junino
  display() {
    if (this.popped) {
      // Se estourou, desenha as partículas
      for (let i = this.particles.length - 1; i >= 0; i--) {
        this.particles[i].update();
        this.particles[i].display();
        if (this.particles[i].isFinished()) {
          this.particles.splice(i, 1);
        }
      }
      return; // Não desenha o corpo do balão se estourado
    }

    noStroke();
    fill(this.color);

    // Corpo principal do balão (elipse)
    ellipse(this.x, this.y, this.r * 1.5, this.r * 2.5);

    // "Ponta" do balão
    triangle(this.x, this.y + this.r * 1.25,
             this.x - this.r * 0.3, this.y + this.r * 1.75,
             this.x + this.r * 0.3, this.y + this.r * 1.75);

    // Linha do balão (simulando barbante)
    stroke(0); // Preto
    strokeWeight(1);
    line(this.x, this.y + this.r * 1.75, this.x, this.y + this.r * 2.5);

    // Chama estilização para detalhes
    this.drawDetails();
  }

  // Adiciona pequenos detalhes decorativos no balão
  drawDetails() {
    noStroke();
    fill(255, 255, 255, 150); // Branco semi-transparente
    ellipse(this.x - this.r * 0.3, this.y - this.r * 0.7, this.r * 0.3);
    ellipse(this.x + this.r * 0.3, this.y - this.r * 0.5, this.r * 0.2);

    // Linhas decorativas (opcional)
    stroke(255, 255, 255, 100);
    strokeWeight(0.5);
    line(this.x - this.r * 0.5, this.y - this.r * 0.5, this.x + this.r * 0.5, this.y + this.r * 0.5);
  }

  move() {
    if (!this.popped) {
      this.y -= this.speed;
    }
  }

  offscreen() {
    // Considera a altura total do balão para verificar se saiu da tela
    return this.y < -this.r * 2.5;
  }

  contains(px, py) {
    // Verifica se o clique está dentro da área aproximada do balão
    let d = dist(px, py, this.x, this.y + this.r * 0.5); // Ajusta o centro para a forma do balão
    return d < this.r * 1.2;
  }

  pop() {
    this.popped = true;
    popSound.play(); // Toca o som de estouro

    // Gera partículas para o efeito de explosão
    for (let i = 0; i < 30; i++) {
      this.particles.push(new Particle(this.x, this.y + this.r * 0.5, this.color));
    }
  }

  // Verifica se o balão já estourou e todas as partículas desapareceram
  isFinished() {
    return this.popped && this.particles.length === 0;
  }
}

// Pré-carregamento de recursos (neste caso, apenas o som)
function preload() {
  // Cria um som simples de "pop" usando a biblioteca p5.sound
  popSound = new p5.Oscillator('sine'); // Um oscilador de onda senoidal
  popSound.freq(500); // Frequência do som
  popSound.amp(0); // Começa com volume 0
  popSound.start(); // Inicia o oscilador (mas silencioso)
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  angleMode(DEGREES); // Usa graus para rotações
  // Configura o som
  popSound.amp(0.3, 0.05); // Define o volume e um pequeno ataque
}

function draw() {
  drawBackground(); // Desenha o fundo e as estrelas
  drawBandeirinhas(); // Desenha as bandeirinhas no topo

  // Lógica para gerar novos balões
  if (millis() - lastBalloonTime > balloonInterval) {
    spawnBalloon();
    lastBalloonTime = millis();
  }

  // Atualiza e desenha os balões
  for (let i = balloons.length - 1; i >= 0; i--) {
    let b = balloons[i];
    b.move();
    b.display();

    // Remove balões que saem da tela ou que já estouraram e desapareceram
    if (b.offscreen() || b.isFinished()) {
      balloons.splice(i, 1);
    }
  }

  displayScore(); // Exibe a pontuação
}

// Função para desenhar o fundo noturno
function drawBackground() {
  // Gradiente do céu noturno
  let c1 = color(20, 0, 50); // Azul bem escuro, quase roxo
  let c2 = color(80, 50, 150); // Azul/roxo mais claro
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(c1, c2, inter);
    stroke(c);
    line(0, y, width, y);
  }

  // Estrelas cintilantes
  randomSeed(99); // Garante que as estrelas sejam sempre as mesmas
  for (let i = 0; i < 100; i++) {
    let x = random(width);
    let y = random(height * 0.7); // Estrelas mais na parte superior do céu
    let starSize = random(1, 3);
    let alpha = map(sin(frameCount * random(0.5, 2) + i * 10), -1, 1, 100, 255); // Efeito cintilante
    fill(255, 255, 200, alpha);
    noStroke();
    ellipse(x, y, starSize);
  }

  // Simula uma fogueira distante ou fumaça
  fill(150, 100, 50, 50); // Marrom avermelhado semi-transparente
  noStroke();
  ellipse(width / 2, height, width * 0.8, height * 0.4); // Base para a fumaça
  fill(200, 150, 100, 30); // Laranja claro semi-transparente
  ellipse(width / 2 + 50, height - 30, width * 0.6, height * 0.3);
}

// Função para desenhar as bandeirinhas no topo
function drawBandeirinhas() {
  let flagHeight = 30;
  let flagWidth = 25;
  let spacing = 40;
  let ropeY = 20;

  stroke(100); // Cor do barbante
  strokeWeight(2);
  line(0, ropeY, width, ropeY); // O barbante principal

  // Desenha as bandeirinhas
  for (let x = 0; x < width + spacing; x += spacing) {
    let flagColor = color(random(255), random(255), random(255)); // Cores aleatórias para cada bandeirinha
    fill(flagColor);
    noStroke();

    push();
    translate(x, ropeY);
    rotate(sin(frameCount * 2 + x * 0.5) * 5); // Pequena oscilação

    // Forma da bandeirinha junina
    beginShape();
    vertex(0, 0);
    vertex(flagWidth, 0);
    vertex(flagWidth, flagHeight * 0.7);
    vertex(flagWidth / 2, flagHeight);
    vertex(0, flagHeight * 0.7);
    endShape(CLOSE);
    pop();
  }
}

// Função para exibir a pontuação
function displayScore() {
  fill(255);
  textSize(32);
  textAlign(RIGHT, TOP);
  // Usa uma fonte mais temática se carregada no preload:
  // textFont('NomeDaSuaFonte');
  text('Pontos: ' + score, width - 20, 20);
}

// Gera um novo balão em uma posição e velocidade aleatórias
function spawnBalloon() {
  let x = random(width * 0.2, width * 0.8); // Balões nascem mais centralizados
  let y = height + 100; // Nascem abaixo da tela
  let r = random(20, 35); // Tamanho aleatório
  let speed = random(1.5, 4); // Velocidade aleatória
  balloons.push(new Balloon(x, y, r, speed));
}

// Lida com o clique do mouse
function mousePressed() {
  for (let i = balloons.length - 1; i >= 0; i--) {
    let b = balloons[i];
    if (b.contains(mouseX, mouseY) && !b.popped) {
      score += 10; // Adiciona pontos
      b.pop(); // Faz o balão estourar
      break; // Estoura apenas um balão por clique
    }
  }
}

// Ajusta o canvas quando a janela é redimensionada
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
